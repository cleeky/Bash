#!/bin/bash

# Functions
 function deleting {
    local source-path   $1
    local source-file   $2
    local file-age      $3


 }

 function archiving {
    local source-path   $1
    local source-file   $2
    local file-age      $3
    local dest-path     $4
    local dest-file     $5


 }

 function copying {
    local source-path   $1
    local source-file   $2
    local file-age      $3
    local dest-path     $4
    local dest-file     $5


 }

 function moving {
    local source-path   $1
    local source-file   $2
    local file-age      $3
    local dest-path     $4
    local dest-file     $5


 }

 function write-log {
    local operation $1
    local status    $2
    local message   $3

    #to get date in yyyymmdd format use date '+%Y%m%d'
    # date '+%Y-%m-%d %T.%6N' = 2024-01-17 20:55:52.922511
    
 }

# Main

# -f <Config File>
# -s <Sourece Path and File>
# -d <Destention Path and File>
# -a Action
# -t Number of Days
# -l LOg File path & name
if [ $OPTIND -eq 1 ]; then 
        echo "Usage: -"
        echo "   ./housekeeper.sh -f <Control file Name>"
        echo "   eg. ./housekeeper.sh clean-list.txt"
        exit 1
fi

while getopts ":f:s:d:a:t:l:" opt; do
    case $opt in
        f) ConfigFileName="$OPTARG"
        ;;
        s) Source="$OPTARG"
        ;;
        d) Dest="$OPTARG"
        ;;
        a) Action="$OPTARG"
        ;;
        t) AgeDays="$OPTARG"
        ;;
        l) LogFile="$OPTARG"
        ;;
        \?) echo "Invalid option -$OPTARG" >&2
            echo "Usage: -"
            echo "   ./housekeeper.sh -f <Control file Name>"
            echo "   eg. ./housekeeper.sh clean-list.txt"
            exit 1
        ;;
    esac
done

if [ "$ConfigFileName" != "" ]
then
    if ! [[ -f "$ConfigFileName" ]]
    then
        echo "Error: -"
        echo "   Can not find/Open '$ConfigFileName' control file"
        exit 1
    fi

    # Read the input file line by line
    while read -r LINE
    do
        IFS="|"
        read -a Control <<< "$LINE"
        Action="${Control[0]}"
        SourcePath="${Control[1]}"
        SourceFile="${Control[2]}"
        AgeDays="${Control[3]}"
        TargetPath="${Control[4]}"
        TargetFile="${Control[5]}"
        LogFile=$(echo "${Control[6]}" | tr -d '\r')

        case $Action in
            A)
                # Archive Action
                echo "Archiving"
                ;;
            C)
                # Copy Action
                printf "Copying"
                ;;
            M)
                # Move Action
                printf "Moving"
                ;;
            D)
                # Delete Action
                printf "Deleting"
                ;;
        esac

    done < "$ConfigFileName"
else
    # User Paramters to do a single action
    echo "Use options to process sigle line command"
    
    SourceName="$(basename "${Source}")"
    SourcePath="$(dirname "${Source}")"
    DestName="$(basename "${Dest}")"
    DestPath="$(dirname "${Dest}")"
    #VAR='/home/pax/file.c'
    #DIR="$(dirname "${VAR}")" ; FILE="$(basename "${VAR}")"
    #echo "[${DIR}] [${FILE}]"
    case $Action in
        A)
            # Archive Action
            echo "Archiving"
            ;;
        C)
            # Copy Action
            printf "Copying"
            ;;
        M)
            # Move Action
            printf "Moving"
            ;;
        D)
            # Delete Action
            printf "Deleting"
            ;;
    esac
fi